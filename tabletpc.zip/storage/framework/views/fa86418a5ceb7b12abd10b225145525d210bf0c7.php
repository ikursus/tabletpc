

<?php $__env->startSection('content'); ?>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    
    <form method="POST" action="">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PATCH'); ?>
        <div class="mb-3">
            <label class="form-label">Nama Pemohon</label>
            <input type="text" class="form-control" name="nama_pemohon" value="<?php echo e($item->nama_pemohon); ?>">
        </div>

        <div class="mb-3">
            <label class="form-label">Jawatan Pemohon</label>
            <input type="text" class="form-control" name="jawatan_pemohon" value="<?php echo e($item->jawatan_pemohon); ?>">
        </div>

        <div class="mb-3">
            <label class="form-label">Gred Pemohon</label>
            <input type="text" class="form-control" name="gred_pemohon" value="<?php echo e($item->gred_pemohon); ?>">
        </div>

        <div class="mb-3">
            <label class="form-label">Jabatan Pemohon</label>
            <input type="text" class="form-control" name="jabatan_pemohon" value="<?php echo e($item->jabatan_pemohon); ?>">
        </div>

        <div class="mb-3">
            <label class="form-label">Jenis Tablet</label>
            <input type="text" class="form-control" name="jenis_tablet" value="<?php echo e($item->jenis_tablet); ?>">
        </div>

        <div class="mb-3">
            <label class="form-label">Harga Belian</label>
            <input type="number" min="0.00" step="0.01" class="form-control" name="harga_belian" value="<?php echo e($item->harga_belian); ?>">
        </div>

        <div class="mb-3">
            <label class="form-label">Tarikh Belian</label>
            <input type="date" class="form-control" name="tarikh_belian" value="<?php echo e($item->tarikh_belian); ?>">
        </div>

        <button type="submit" class="btn btn-primary">Update</button>
    </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('induk', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\tabletpc\resources\views/semakan/edit.blade.php ENDPATH**/ ?>