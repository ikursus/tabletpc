

<?php $__env->startSection('content'); ?>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    
    <form method="POST" action="">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label class="form-label">Nama Pemohon</label>
            <input type="text" class="form-control" name="nama_pemohon">
        </div>

        <div class="mb-3">
            <label class="form-label">Jawatan Pemohon</label>
            <input type="text" class="form-control" name="jawatan_pemohon">
        </div>

        <div class="mb-3">
            <label class="form-label">Gred Pemohon</label>
            <input type="text" class="form-control" name="gred_pemohon">
        </div>

        <div class="mb-3">
            <label class="form-label">Jabatan Pemohon</label>
            <input type="text" class="form-control" name="jabatan_pemohon">
        </div>

        <div class="mb-3">
            <label class="form-label">No. Pekerja Pemohon</label>
            <input type="text" class="form-control" name="no_pekerja">
        </div>

        <div class="mb-3">
            <label class="form-label">Jenis Tablet</label>
            <input type="text" class="form-control" name="jenis_tablet">
        </div>

        <div class="mb-3">
            <label class="form-label">Harga Belian</label>
            <input type="number" min="0.00" step="0.01" class="form-control" name="harga_belian">
        </div>

        <div class="mb-3">
            <label class="form-label">Tarikh Belian</label>
            <input type="date" class="form-control" name="tarikh_belian">
        </div>

        <button type="submit" class="btn btn-primary">Submit</button>
    </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('induk', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\tabletpc\resources\views/semakan/borang.blade.php ENDPATH**/ ?>