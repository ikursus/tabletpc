

<?php $__env->startSection('content'); ?>
    
    <?php $__currentLoopData = $senaraiPermohonan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permohonan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li><?php echo e($permohonan->nama_pemohon); ?></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('induk', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\tabletpc\resources\views/template_permohonan/senarai_permohonan.blade.php ENDPATH**/ ?>