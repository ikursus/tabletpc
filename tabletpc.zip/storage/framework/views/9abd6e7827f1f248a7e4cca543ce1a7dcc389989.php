

<?php $__env->startSection('content'); ?>

<p>
    <a href="/permohonan/baru" class="btn btn-primary">Hantar Permohonan</a>
</p>

    <table class="table">
        <thead>
            <th>PENGIRIM BORANG</th>
            <th>NAMA PEMOHON</th>
            <th>JAWATAN PEMOHON</th>
            <th>JABATAN PEMOHON</th>
            <th>JENIS TABLET</th>
            <th>HARGA BELIAN</th>
            <th>TARIKH BELIAN</th>
            <th>TINDAKAN</th>
        </thead>
        <tbody>
            <?php $__currentLoopData = $senaraiPermohonan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($item->name); ?></td>
                <td><?php echo e($item->nama_pemohon); ?></td>
                <td><?php echo e($item->jawatan_pemohon); ?></td>
                <td><?php echo e($item->jabatan_pemohon); ?></td>
                <td><?php echo e($item->jenis_tablet); ?></td>
                <td><?php echo e($item->harga_belian); ?></td>
                <td><?php echo e($item->tarikh_belian); ?></td>
                <td>
                    <a href="/permohonan/<?php echo e($item->id); ?>" class="btn btn-info">
                        EDIT
                    </a>
                    
                        <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#modal-delete-<?php echo e($item->id); ?>">
                            DELETE
                        </button>
                    

                    <!-- Button trigger modal -->
                    <!-- Modal -->
                    <div class="modal fade" id="modal-delete-<?php echo e($item->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog">
                            
                            <form method="POST" action="/permohonan/<?php echo e($item->id); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>

                                    <div class="modal-content">
                                        <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">Pengesahan Delete</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            Adakah anda bersetuju untuk menghapuskan data <?php echo e($item->id); ?>

                                        </div>
                                        <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                        <button type="submit" class="btn btn-danger">Confirm</button>
                                        </div>
                                    </div>

                            </form>
                        </div>
                    </div>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>  

    <?php echo $senaraiPermohonan->links(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('induk', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\tabletpc\resources\views/template_permohonan/senarai.blade.php ENDPATH**/ ?>