<?php

// Code / Helper config() akan mencari folder
// yang bernama config
echo config('app.name');
echo '<br>';
// Laravel akan mencari fail yang bernama .env
// echo env('DB_CONNECTION');

echo config('tabletpc.hakcipta');
echo '. Versi ';
echo config('tabletpc.versi'); ?><?php /**PATH C:\laragon\www\tabletpc\resources\views/welcome.blade.php ENDPATH**/ ?>