
    
<?php $__env->startSection('content'); ?>


    <h1>Halaman Semakan ID: <?php echo e($id); ?></h1>
    <p>No ID Permohonan adalah <?php echo e($id); ?></p>
    <p><?php echo e($input_nama); ?></p>
    <p><?php echo $input_nama; ?></p>

    <?php

    $warna = 'merah';

    if ($warna == 'merah')
    {
        echo 'Saya suka warna merah';
    }
    else
    {
        echo 'saya mahu warna merah';
    }

    ?>

    <?php
    $warna = 'pink'
    ?>

    <?php if($warna == 'biru'): ?>
    Saya suka Warna biru
    <?php else: ?>
    Saya Mahu warna biru
    <?php endif; ?>

    


<?php $__env->stopSection(); ?>    
    
<?php echo $__env->make('induk', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\tabletpc\resources\views/semakan/template_detail_semakan.blade.php ENDPATH**/ ?>