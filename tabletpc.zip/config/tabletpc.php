<?php

return [
    'versi' => '1.0.0',
    'hakcipta' => 'Hak Cipta &copy; 2021 Majlis Perbandaran Selayang',
];